/* Global Variables */
const myKey = '9bce6bc37fecbee0a32eab9f8d192447&units=metric';

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = (d.getMonth() + 1) + '.' + d.getDate() + '.' + d.getFullYear();

// Adding an event listner to generate button
const generate = document.querySelector('#generate');
generate.addEventListener('click', doYourThing);

// Chained promises to post,get data and apdate the UI
function doYourThing() {
    const userFeelings = document.querySelector('#feelings').value; // Storing user feelings 
    getWeatherData().then(data => postWeatherData('/addWeatherData',
        {
            date: newDate,
            Temp: data.main.temp,
            feelings: userFeelings
        }).then(updateUI())
    )
};

// Creating async function that fetches weather data corresponding to the user zip code
const getWeatherData = async () => {
    const zipCode = document.querySelector('#zip').value; // Storeing user zip code in a variable
    const url = `https://api.openweathermap.org/data/2.5/weather?zip=${zipCode}&appid=`; // Creating a dynamic url
    try {
        if (!zipCode) { // Cheaking if the user enter a zip code
            alert('please enter a zip code');
            return
        }
        const newData = await fetch(url+myKey); // Storeing wetching data in a newData variable
        const weatherData = await newData.json(); // Converting data to json
        console.log(weatherData.main.temp)
        return weatherData;
    } catch (err) { // Handling errors
        console.log('error', err);
        alert('please enter a valid zip code');
    }
};

// Creating async function to post date to a url
const postWeatherData = async (url = '', data = {}) => {
    const response = await fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data),
    });

    try {
        const newData = await response.json();
        console.log(newData)
    } catch (err) {
        console.log('error', err)
    }
}

// Creating async function that updates the UI
const updateUI = async () => {
    const request = await fetch('/allData') // Fetching posted data from the rout created in server side and storing it in a variable
    try {
        const allData = await request.json(); // Converting posted data to json
        console.log(allData);
        document.querySelector('#temp').innerHTML = allData.Temperature; // Updating the tempurature in the holder
        document.querySelector('#content').innerHTML = allData.Feelings; // Updating the feelings in the holder
        document.querySelector('#date').innerHTML = allData.Date; // Updating the date in the holder
    } catch (err) { // Handling errors
        console.log('erroe', err)
    }
}




