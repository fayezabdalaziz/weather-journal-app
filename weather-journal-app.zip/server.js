// Setup empty JS object to act as endpoint for all routes
projectData = {};
const port = 3000;

// Require Express to run server and routes
const express = require('express');

// Start up an instance of app
const app = express();

/* Middleware*/
const bodyParser = require('body-parser');

//Here we are configuring express to use body-parser as middle-ware.
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Cors for cross origin allowance
const cors = require('cors');
app.use(cors());

// Initialize the main project folder
app.use(express.static('website'));

// Setup Server
app.listen(port, () => console.log(`server is running at http://localhost:${port}`));

// Creating a post rout to post data to the end point dataEndPoint
app.post('/addWeatherData', addWeatherData);

let dataEndPoint = []; // Creating an end point to store data posted
function addWeatherData(req, res) { 
    userData = { // Object holding the data to post
        Date: req.body.date, 
        Temperature: req.body.Temp, 
        Feelings: req.body.feelings 
    }
    projectData = userData; // Adding data to the end point
    console.log(projectData)
}

// Creating a get rout to retrieve data from the end point dataEndPoint
app.get('/allData', getWeather)

function getWeather(req, res) {
    res.send(projectData); //Sending data
    return projectData = {}
}